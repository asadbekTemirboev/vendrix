/* =========================================
   VENDRIX — Main Scripts (Telegram)
   ========================================= */

(function () {
    'use strict';

    /* ============================================
       📱 TELEGRAM — настройки
       ============================================ */
    var TG_BOT_TOKEN = '8670387498:AAFg3LJ192EJB1Cl3B05jbU2WCBN8mTGcfo';
    var TG_CHAT_ID = '8865814495';
    var TG_API = 'https://api.telegram.org/bot' + TG_BOT_TOKEN + '/sendMessage';


    /* ===== PRELOADER ===== */
    var preloader = document.getElementById('preloader');
    var preloaderBar = document.getElementById('preloaderBar');
    var progress = 0;

    var progressInterval = setInterval(function () {
        progress += Math.random() * 22;
        if (progress > 100) progress = 100;
        if (preloaderBar) preloaderBar.style.width = progress + '%';

        if (progress >= 100) {
            clearInterval(progressInterval);
            setTimeout(function () {
                if (preloader) preloader.classList.add('hidden');
                document.body.classList.remove('loading');
                document.body.classList.add('ready');
                setTimeout(function () {
                    if (preloader) preloader.style.display = 'none';
                }, 700);
            }, 400);
        }
    }, 160);

    setTimeout(function () {
        if (preloader && !preloader.classList.contains('hidden')) {
            preloader.classList.add('hidden');
            document.body.classList.remove('loading');
            document.body.classList.add('ready');
            setTimeout(function () { preloader.style.display = 'none'; }, 700);
        }
    }, 4000);


    /* ===== PARTICLES ===== */
    var particlesContainer = document.getElementById('heroParticles');
    if (particlesContainer) {
        for (var i = 0; i < 25; i++) {
            var p = document.createElement('span');
            p.className = 'hero-particle';
            p.style.left = Math.random() * 100 + '%';
            p.style.animationDuration = (8 + Math.random() * 12) + 's';
            p.style.animationDelay = (Math.random() * 10) + 's';
            particlesContainer.appendChild(p);
        }
    }


    /* ===== NAVBAR SCROLL ===== */
    var navbar = document.getElementById('navbar');
    function handleNavScroll() {
        if (!navbar) return;
        if (window.scrollY > 40) navbar.classList.add('scrolled');
        else navbar.classList.remove('scrolled');
    }
    window.addEventListener('scroll', handleNavScroll, { passive: true });
    handleNavScroll();


    /* ===== MOBILE MENU ===== */
    var burger = document.getElementById('burger');
    var navLinks = document.getElementById('navLinks');
    if (burger && navLinks) {
        burger.addEventListener('click', function () {
            burger.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
        navLinks.querySelectorAll('a').forEach(function (a) {
            a.addEventListener('click', function () {
                burger.classList.remove('active');
                navLinks.classList.remove('active');
            });
        });
    }


    /* ===== SCROLL REVEAL ===== */
    var revealEls = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
        var ro = new IntersectionObserver(function (entries) {
            entries.forEach(function (e) {
                if (e.isIntersecting) {
                    e.target.classList.add('active');
                    ro.unobserve(e.target);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });
        revealEls.forEach(function (el) { ro.observe(el); });
    } else {
        revealEls.forEach(function (el) { el.classList.add('active'); });
    }


    /* ===== SMOOTH ANCHOR SCROLL ===== */
    document.querySelectorAll('a[href^="#"]').forEach(function (a) {
        a.addEventListener('click', function (e) {
            var href = this.getAttribute('href');
            if (href === '#' || href === '') return;
            var target = document.querySelector(href);
            if (!target) return;
            e.preventDefault();
            var offset = 80;
            var top = target.getBoundingClientRect().top + window.pageYOffset - offset;
            window.scrollTo({ top: top, behavior: 'smooth' });
        });
    });


    /* ===== HERO TILT ===== */
    var heroVisual = document.querySelector('.hero-visual');
    var tilt = document.getElementById('heroVisualTilt');
    if (heroVisual && tilt && window.matchMedia('(min-width: 1024px)').matches) {
        heroVisual.addEventListener('mousemove', function (e) {
            var rect = heroVisual.getBoundingClientRect();
            var x = (e.clientX - rect.left) / rect.width - 0.5;
            var y = (e.clientY - rect.top) / rect.height - 0.5;
            tilt.style.transform = 'rotateY(' + (x * 10) + 'deg) rotateX(' + (-y * 10) + 'deg)';
        });
        heroVisual.addEventListener('mouseleave', function () {
            tilt.style.transform = 'rotateY(0) rotateX(0)';
        });
    }


    /* ===== CURSOR GLOW ===== */
    document.querySelectorAll('.service-card').forEach(function (card) {
        var glow = card.querySelector('.service-card-glow');
        if (!glow) return;
        card.addEventListener('mousemove', function (e) {
            var rect = card.getBoundingClientRect();
            glow.style.left = (e.clientX - rect.left - 100) + 'px';
            glow.style.top = (e.clientY - rect.top - 100) + 'px';
        });
    });


    /* ===== CINEMATIC JOURNEY ===== */
    var journeySection = document.querySelector('.journey');
    var journeyScenes = document.querySelectorAll('.journey-scene');
    var journeyLabels = document.querySelectorAll('.journey-plabel');
    var journeyFill = document.getElementById('journeyFill');
    var currentScene = 0;

    function setJourneyScene(index) {
        if (index === currentScene) return;
        currentScene = index;
        journeyScenes.forEach(function (s, i) {
            s.classList.toggle('active', i === index);
        });
        journeyLabels.forEach(function (l, i) {
            l.classList.toggle('active', i === index);
            l.classList.toggle('passed', i < index);
        });
        if (journeyFill) {
            var percent = (index / (journeyScenes.length - 1)) * 100;
            journeyFill.style.width = percent + '%';
        }
    }

    function handleJourneyScroll() {
        if (!journeySection) return;
        var rect = journeySection.getBoundingClientRect();
        var totalScroll = journeySection.offsetHeight - window.innerHeight;
        if (totalScroll <= 0) return;
        var prog = -rect.top / totalScroll;
        prog = Math.max(0, Math.min(0.9999, prog));
        var totalScenes = journeyScenes.length;
        var idx = Math.floor(prog * totalScenes);
        if (idx >= totalScenes) idx = totalScenes - 1;
        setJourneyScene(idx);
    }

    if (journeySection && journeyScenes.length) {
        setJourneyScene(0);
        journeyScenes[0].classList.add('active');
        window.addEventListener('scroll', handleJourneyScroll, { passive: true });
        window.addEventListener('resize', handleJourneyScroll);
        handleJourneyScroll();
    }


    /* ===== NUMBER COUNTER ===== */
    var counters = document.querySelectorAll('.hero-trust-value');
    if (counters.length && 'IntersectionObserver' in window) {
        var co = new IntersectionObserver(function (entries) {
            entries.forEach(function (e) {
                if (!e.isIntersecting) return;
                var el = e.target;
                var text = el.textContent;
                var match = text.match(/^(\d+(?:\.\d+)?)/);
                if (!match) return;
                var target = parseFloat(match[1]);
                var suffix = text.replace(match[1], '');
                var start = performance.now();
                function update(now) {
                    var p = Math.min((now - start) / 1600, 1);
                    var eased = 1 - Math.pow(1 - p, 3);
                    var cur = target * eased;
                    var formatted = Number.isInteger(target) ? Math.round(cur) : cur.toFixed(1);
                    el.innerHTML = formatted + suffix;
                    if (p < 1) requestAnimationFrame(update);
                }
                requestAnimationFrame(update);
                co.unobserve(el);
            });
        }, { threshold: 0.5 });
        counters.forEach(function (el) { co.observe(el); });
    }


    /* ==========================================
       MODAL
       ========================================== */
    var modal = document.getElementById('contactModal');
    var modalForm = document.getElementById('modalForm');
    var modalSuccess = document.getElementById('modalSuccess');

    function openModal() {
        if (!modal) return;
        modal.classList.add('open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('modal-open');
        if (modalForm) {
            modalForm.style.display = '';
            modalForm.reset();
            modalForm.querySelectorAll('.error').forEach(function (el) {
                el.classList.remove('error');
            });
        }
        if (modalSuccess) modalSuccess.classList.remove('show');
        setTimeout(function () {
            var firstInput = modal.querySelector('input[name="name"]');
            if (firstInput) firstInput.focus();
        }, 300);
    }

    function closeModal() {
        if (!modal) return;
        modal.classList.add('closing');
        setTimeout(function () {
            modal.classList.remove('open', 'closing');
            modal.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('modal-open');
        }, 300);
    }

    document.querySelectorAll('.js-open-modal').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            openModal();
        });
    });

    if (modal) {
        modal.querySelectorAll('[data-close-modal]').forEach(function (el) {
            el.addEventListener('click', closeModal);
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && modal.classList.contains('open')) {
                closeModal();
            }
        });
    }


    /* ==========================================
       📱 ОТПРАВКА В TELEGRAM
       ========================================== */
    function showSuccess() {
        if (modalForm) modalForm.style.display = 'none';
        if (modalSuccess) modalSuccess.classList.add('show');
    }

    function sendToTelegram(lead) {
        var now = new Date();
        var dateStr = now.toLocaleString('ru-RU', {
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
        var leadId = 'L' + now.getTime();

        var text = '🆕 <b>Новая заявка с сайта!</b>\n' +
            '━━━━━━━━━━━━━━━━\n\n' +
            '👤 <b>Имя:</b> ' + escapeHtml(lead.name) + '\n' +
            (lead.company ? '🏢 <b>Компания:</b> ' + escapeHtml(lead.company) + '\n' : '') +
            '📞 <b>Контакт:</b> ' + escapeHtml(lead.contact) + '\n' +
            (lead.service ? '💼 <b>Услуга:</b> ' + escapeHtml(lead.service) + '\n' : '') +
            (lead.budget ? '💰 <b>Бюджет:</b> ' + escapeHtml(lead.budget) + '\n' : '') +
            (lead.task ? '📝 <b>Задача:</b> ' + escapeHtml(lead.task) + '\n' : '') +
            '\n━━━━━━━━━━━━━━━━\n' +
            '🌐 <b>Источник:</b> Лендинг vendrix.io\n' +
            '🕐 <b>Время:</b> ' + dateStr + '\n' +
            '🔑 <b>ID:</b> <code>' + leadId + '</code>';

        // Сохраняем в localStorage (для CRM)
        try {
            var leads = JSON.parse(localStorage.getItem('vendrix_leads') || '[]');
            leads.unshift({
                id: leadId,
                date: dateStr,
                name: lead.name,
                company: lead.company,
                contact: lead.contact,
                service: lead.service,
                budget: lead.budget,
                task: lead.task,
                status: 'new',
                source: 'Лендинг vendrix.io'
            });
            localStorage.setItem('vendrix_leads', JSON.stringify(leads));
        } catch (e) {}

        return fetch(TG_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: TG_CHAT_ID,
                text: text,
                parse_mode: 'HTML'
            })
        });
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    if (modalForm) {
        modalForm.addEventListener('submit', function (e) {
            e.preventDefault();

            var form = this;
            var submitBtn = form.querySelector('button[type="submit"]');
            var originalHTML = submitBtn ? submitBtn.innerHTML : '';

            // Валидация
            var nameField = form.querySelector('[name="name"]');
            var contactField = form.querySelector('[name="contact"]');
            var privacyField = form.querySelector('[name="privacy"]');
            var valid = true;

            if (nameField && !nameField.value.trim()) {
                nameField.classList.add('error');
                valid = false;
            }
            if (contactField && !contactField.value.trim()) {
                contactField.classList.add('error');
                valid = false;
            }
            if (privacyField && !privacyField.checked) {
                valid = false;
                alert('Пожалуйста, согласитесь с политикой конфиденциальности');
            }

            if (!valid) return;

            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = 'Отправляем...';
            }

            var lead = {
                name: (form.querySelector('[name="name"]') || {}).value || '',
                company: (form.querySelector('[name="company"]') || {}).value || '',
                contact: (form.querySelector('[name="contact"]') || {}).value || '',
                budget: (form.querySelector('[name="budget"]') || {}).value || '',
                service: (form.querySelector('[name="service"]') || {}).value || '',
                task: (form.querySelector('[name="task"]') || {}).value || ''
            };

            console.log('📤 Отправляем в Telegram:', lead);

            sendToTelegram(lead)
                .then(function (response) {
                    return response.json();
                })
                .then(function (data) {
                    if (data.ok) {
                        console.log('✅ Заявка отправлена в Telegram');
                        showSuccess();
                    } else {
                        console.error('❌ Ошибка Telegram:', data);
                        showSuccess();
                    }
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalHTML;
                    }
                })
                .catch(function (err) {
                    console.error('❌ Ошибка:', err);
                    showSuccess();
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalHTML;
                    }
                });
        });
    }


    /* ==========================================
       SOCIAL
       ========================================== */
    var socialModal = document.getElementById('socialModal');
    var floatingSocial = document.getElementById('floatingSocial');
    var floatingToggle = document.getElementById('floatingToggle');
    var socialBanner = document.getElementById('socialBanner');
    var socialBannerClose = document.getElementById('socialBannerClose');
    var openContactFromSocial = document.getElementById('openContactFromSocial');

    function openSocialModal() {
        if (!socialModal) return;
        socialModal.classList.add('open');
        socialModal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('modal-open');
    }
    function closeSocialModal() {
        if (!socialModal) return;
        socialModal.classList.add('closing');
        setTimeout(function () {
            socialModal.classList.remove('open', 'closing');
            socialModal.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('modal-open');
        }, 300);
    }

    if (socialModal) {
        socialModal.querySelectorAll('[data-close-social]').forEach(function (el) {
            el.addEventListener('click', closeSocialModal);
        });
    }

    if (floatingToggle && floatingSocial) {
        floatingToggle.addEventListener('click', function (e) {
            e.stopPropagation();
            floatingSocial.classList.toggle('open');
        });
        document.addEventListener('click', function (e) {
            if (floatingSocial.classList.contains('open') &&
                !floatingSocial.contains(e.target)) {
                floatingSocial.classList.remove('open');
            }
        });
    }

    var BANNER_KEY = 'vendrix_banner_closed';
    function showBanner() {
        if (!socialBanner) return;
        try {
            if (sessionStorage.getItem(BANNER_KEY) === '1') return;
        } catch (e) {}
        socialBanner.classList.remove('hidden');
        setTimeout(function () {
            socialBanner.classList.add('show');
            socialBanner.setAttribute('aria-hidden', 'false');
        }, 80);
    }
    function hideBanner(remember) {
        if (!socialBanner) return;
        socialBanner.classList.remove('show');
        socialBanner.setAttribute('aria-hidden', 'true');
        if (remember) {
            try { sessionStorage.setItem(BANNER_KEY, '1'); } catch (e) {}
        }
        setTimeout(function () {
            socialBanner.classList.add('hidden');
        }, 700);
    }
    if (socialBanner) {
        setTimeout(showBanner, 3500);
        if (socialBannerClose) {
            socialBannerClose.addEventListener('click', function () {
                hideBanner(true);
            });
        }
        socialBanner.querySelectorAll('a').forEach(function (a) {
            a.addEventListener('click', function () { hideBanner(true); });
        });
    }

    if (openContactFromSocial) {
        openContactFromSocial.addEventListener('click', function () {
            closeSocialModal();
            setTimeout(function () {
                var mainModal = document.getElementById('contactModal');
                if (mainModal) {
                    mainModal.classList.add('open');
                    mainModal.setAttribute('aria-hidden', 'false');
                    document.body.classList.add('modal-open');
                }
            }, 300);
        });
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && socialModal && socialModal.classList.contains('open')) {
            closeSocialModal();
        }
    });

})();